package FruitApp;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Fruit {

    private String name;
    private int age;

    List<String> fruit_characteristic;

    public Fruit(String name, int age, List<String> characteristics)
    {
        this.name= name;
        this.age=age;
        this.fruit_characteristic=characteristics;


    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getCharacteristic() {
        String char1w = this.fruit_characteristic.toString().replace("[", "").replace("]", "");
        return char1w;
    }


    @Override
    public String toString() {
        return
                "name='" + name + '\'' +
                        ", age=" + age +
                        ", characteristic=" + fruit_characteristic
                ;
    }
}
