package FruitApp;

import java.io.*;
import java.io.FileReader;
import java.util.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.function.Function;


import java.io.IOException;
import java.util.ArrayList;

import static java.util.stream.Collectors.*;


public class MyFruitBasket {

    /**
     * MyFruitBasket is a simple console application which computes
     *
     * Total count of all fruits in the CVS-file
     * Total count of distinct fruit types in the basket
     * The fruit type and age of the oldest fruit in the basket in days
     * Count of all fruits grouped by fruit types in descending order
     * Count of all fruits grouped by fruit type and all characteristics in descending order
     *
     * @author Anitha Kolluri
     */


    List<Fruit> fruitList = new ArrayList<Fruit>();
    Fruit sample;
    /**
     * Reads application data from a file
     *
     * @param fileName file of application data
     * @param
     * @return array of double values
     */


    public void generateFruitList(String fileName) throws FileNotFoundException {

        File inputFile = new File(fileName);
        //throws an exception if file is not found
        if(!inputFile.exists()){
            throw new FileNotFoundException("Input file not found, Specify the right path to the input file.");
        }
        fruitList = validateDataAndCreateInputList(fileName);
        GenerateSummaryReport(fruitList);

    }


    private List<Fruit> validateDataAndCreateInputList(String fileName) throws FileNotFoundException {
        String line = "";
        List<String> character;

        BufferedReader reader;
        reader = new BufferedReader(new FileReader(fileName));

        try {

                //Skip the header in the csv file
            if (reader.readLine() == null) {
                System.out.println("No errors but input file is empty. Please provide valid input. ");
                System.exit(1);
            }
                while ((line = reader.readLine()) != null) {
                    character = new ArrayList<String>();

                    //Read the contents of the input file.
                    String[] row = line.split(",");
                    if (row.length >= 4) {
                        if (row[0] != null && Integer.parseInt(row[1]) > 0 && row[2] != null && row[3] != null) {
                            for (int i = 2; i < row.length; i++) {
                                character.add(row[i]);
                            }
                            sample = new Fruit(row[0], Integer.parseInt(row[1]), character);
                            fruitList.add(sample);
                        } else {
                            System.err.println("Input file is not in proper format! Please update the file with right information and rerun.");
                            System.exit(130);

                        }
                    }
                }


        } catch (IOException ex) {

            System.err.println("Failed to read file");
            System.err.println(ex.toString());
            System.exit(1);
        } finally
        {
            try {
                //Close the input file
                reader.close();
                } catch (IOException e)
            {
                System.err.println("An IOException was caught!");
                e.printStackTrace();
            }


        }
return fruitList;
    }


    /**
     * Calculates and prints the required information
     *
     * @param
     */
    private void GenerateSummaryReport(List<Fruit> fruitBasket) {

        //Total number of fruit:
        System.out.println("\nTotal Number of fruits in the basket:\n" + fruitList.size());

        Map<String, Long> result = fruitList.stream().collect(groupingBy(Fruit::getName, counting()));
        System.out.println("\nTotal types of fruits in the basket:\n" + result.size());
        System.out.println("\nThe number of each type of fruit in descending order: " );
        result.forEach((k, v) -> System.out.println(k + ":\t" + v));

        Map<Integer, Set<String>> result1 = fruitList.stream().collect(groupingBy(Fruit::getAge, mapping(Fruit::getName, toSet())));
        System.out.println("\nOldest Fruit & Age: " );
        for(String s: result1.get(result1.size()))
            System.out.println(s +": " + result1.size());


        Function<Fruit, List<Object>> compositeKey = Fruit -> Arrays.<Object>asList(Fruit.getCharacteristic());
        Map<List<Object>, Long> collected2=fruitList.stream()
                .collect(
                        Collectors.groupingBy(compositeKey, Collectors.mapping(
                                Fruit::getName,
                                counting())));


        //Characteristics of each fruit by type
        Map<String, Long> collected3= fruitList.stream()
                .collect(
                        Collectors.groupingBy(s->s.getName()+ ": " +s.getCharacteristic(),LinkedHashMap::new,
                                Collectors.counting()));

        System.out.println("\n \nThe various characteristics (count, color, shape, etc.) of each fruit by type: ");
        collected3.forEach((k, v) -> System.out.println(v + " \t" + k));




    }


}
