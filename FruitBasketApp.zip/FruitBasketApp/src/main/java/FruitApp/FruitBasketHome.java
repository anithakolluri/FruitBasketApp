package FruitApp;

import java.io.*;

/**
 * Starting of the Application.
 *
 * @author Anitha Kolluri
 */
public class FruitBasketHome {

    /**
     * Application entry point.
     *
     * @param args application command line argument with the path to input file name
     */

    public static void main(String args[]) throws FileNotFoundException {


        //System.out.println("Enter the path to the input file :");
        MyFruitBasket app = new MyFruitBasket();
        app.generateFruitList(args[0]);

    }
    }





